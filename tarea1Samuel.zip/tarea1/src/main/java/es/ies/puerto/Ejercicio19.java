package es.ies.puerto;
/**
 * Declara una variable double para almacenar la raíz cuadrada de 2.
 * Usa la clase Math para calcular el valor y muéstralo por pantalla.
 * @author Shbarroso
 */
public class Ejercicio19 {
    public static void main(String[] args) {
        double raizCuadrada = Math.sqrt(4);
        System.out.println("La raiz cuadrada de cuatro es: "+raizCuadrada);
    }
}