package es.ies.puerto;
/**
 * Declara dos variables de tipo boolean: una que indique si una persona
 * tiene licencia de conducir y otra si posee un vehículo. Muestra ambas variables.
 * @author Shbarroso
 */
public class Ejercicio14 {
    public static void main(String[] args) {
        boolean tieneLicencia = true;
        boolean tieneCoche = true;

        System.out.println("Si tiene licensia de conducir: " +tieneLicencia);
        System.out.println("Si tiene vehiculo: " +tieneCoche);

    }
}