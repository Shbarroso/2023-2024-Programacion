package es.ies.puerto;
/**
 * Declara una variable de tipo float que almacene el resultado de
 * dividir 5 entre 2. Muestra el resultado en la consola.
 * @author Shbarroso
 */
public class Ejercicio18 {
    public static void main(String[] args) {
        int numero1 = 5;
        int numero2 = 2;
        float division = numero1/numero2;
        System.out.println("La divion entre "+numero1+" y "+numero2+ " es: " +division);
    }
}