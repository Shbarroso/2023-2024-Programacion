package es.ies.puerto;
/**
 * Declara dos variables de tipo int y realiza una división entre ambas.
 * Muestra el resultado de la división entera y el residuo.
 * @author Shbarroso
 */
public class Ejercicio16 {
    public static void main(String[] args) {
        int numero1 = 10;
        int numero2 = 5;
        int division = numero1/numero2;
        int residuo = numero1 % numero2;
        System.out.println("La division es: "+division+ " y el residuo es: "+residuo);
    }
}