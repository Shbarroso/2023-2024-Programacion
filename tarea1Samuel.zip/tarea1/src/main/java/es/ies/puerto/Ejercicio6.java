package es.ies.puerto;
/**
 * Declara tres variables enteras, asigna valores a cada una y calcula su promedio.
 * @author Shbarroso
 */
public class Ejercicio6 {
    public static void main(String[] args) {
        int numero1 = 2;
        int numero2 = 2;
        int numero3 = 2;
        int promedio;
        int suma = numero1 + numero2 + numero3;
        promedio = (suma) /3;
        System.out.println("El promedio es: " +promedio);
    }
}