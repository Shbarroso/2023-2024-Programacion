package es.ies.puerto;
/**
 * Declara una variable entera para almacenar tu edad 
 * y muestra su valor por pantalla.
 * @author Shbarroso
 */
public class Ejercicio1 {
    public static void main(String[] args) {
         int edad = 20;
        System.out.println("Mi edad es:" +edad);
    }
}