package es.ies.puerto;
/**
 * Declara una variable de tipo Stringpara almacenar una dirección
 * de correo electrónico. Muéstrala en la consola.
 * @author Shbarroso
 */
public class Ejercicio13 {
    public static void main(String[] args) {
        String correo = "samuelaurix2@gmail.com";
        System.out.println("Mi email es: "+correo);
    }
}