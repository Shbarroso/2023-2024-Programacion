package es.ies.puerto;
/**
 * Declara una variable de tipo String que almacene 
 * tu nombre completo. Muestra por pantalla el nombre.
 * @author Shbarroso
 */
public class Ejercicio5 {
    public static void main(String[] args) {
        String nombre = "Samuel Hernandez Barroso";
        System.out.println("Mi nombre es: "+nombre);
    }
}