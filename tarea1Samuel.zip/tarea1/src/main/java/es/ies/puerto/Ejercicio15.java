package es.ies.puerto;
/**
 * Declara una variable de tipo char y asígnale un símbolo del
 * teclado. Luego, muestra el código numérico ASCII de ese símbolo.
 * @author Shbarroso
 */
public class Ejercicio15 {
    public static void main(String[] args) {
        char simbolo = '&';
        int codigoAscii = simbolo;
        System.out.println("El simbolo del codigo Ascii es: "+codigoAscii);
    }
}