package es.ies.puerto;
/**
 * Declara una variable de tipo short para almacenar la cantidad de días en un año (365).
 * Asigna el valor y muéstralo por pantalla.
 * @author Shbarroso
 */
public class Ejercicio12 {
    public static void main(String[] args) {
        short diasAno = 365;
        System.out.println("Los dias en un ano son: "+diasAno);
    }
}