package es.ies.puerto;
/**
 * Crea una variable char que almacene la primera 
 * letra de tu nombre y muéstrala por pantalla.
 * @author Shbarroso
 */
public class Ejercicio3 {
    public static void main(String[] args) {
        char primeraLetra = 'S'; 
        System.out.println("La primera letra de mi nombre es: " + primeraLetra);
    }
}