package es.ies.puerto;
/**
 * Declara una variable de tipo long para almacenar un valor numérico grande,
 * como la población mundial. Asigna un valor y muéstralo por pantalla.
 * @author Shbarroso
 */
public class Ejercicio11 {
    public static void main(String[] args) {
        long numeroGrande = 1234567892;
        System.out.println("La poblacion mundial es: " + numeroGrande);
    }
}